let GroupOfCards = ["🤣", "😉", "😍", "😗", "😶‍🌫️", "🙈", "👻", "💩"];

let totalCards = GroupOfCards.concat(GroupOfCards);
